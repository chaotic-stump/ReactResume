# React Resume

Built with:
- React
- Babel
- Bootstrap
- HTML/CSS (of course)

Inspired by Kirupa's awesome tutorial:
https://www.kirupa.com/react/creating_single_page_app_react_using_react_router.htm
